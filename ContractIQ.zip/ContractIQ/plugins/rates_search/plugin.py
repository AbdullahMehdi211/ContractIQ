import os
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from openai import AzureOpenAI

load_dotenv()


class RatesSearchPlugin:
    def __init__(self):
        self.search_client = SearchClient(
            endpoint=os.environ["AZURE_SEARCH_ENDPOINT"],
            index_name=os.environ.get("AZURE_SEARCH_INDEX_NAME", "contract-rates"),
            credential=AzureKeyCredential(os.environ["AZURE_SEARCH_ADMIN_KEY"]),
        )

        self.aoai = AzureOpenAI(
            api_key=os.environ["AZURE_OPENAI_API_KEY"],
            azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
            api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
        )
        self.embedding_deployment = os.environ["AZURE_OPENAI_EMBEDDING_DEPLOYMENT"]

    def hybrid_search(
        self,
        query: str,
        top_k: int = 5,
        medication_type: Optional[str] = None,
        document_name: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        # embeddings input MUST be a list for Azure OpenAI python client reliability
        emb = self.aoai.embeddings.create(
            model=self.embedding_deployment,
            input=[str(query)],
        ).data[0].embedding

        vq = VectorizedQuery(
            vector=emb,
            fields="text_vector",
            k_nearest_neighbors=top_k,
        )

        filters = []
        if medication_type:
            filters.append(f"medication_type eq '{medication_type}'")
        if document_name:
            filters.append(f"document_name eq '{document_name}'")
        filter_expr = " and ".join(filters) if filters else None

        results = self.search_client.search(
            search_text=query,
            vector_queries=[vq],
            filter=filter_expr,
            top=top_k,
        )

        out: List[Dict[str, Any]] = []
        for r in results:
            out.append(
                {
                    "id": r.get("id"),
                    "document_name": r.get("document_name"),
                    "medication_type": r.get("medication_type"),
                    "category": r.get("category"),
                    "text": r.get("text"),
                }
            )
        return out
