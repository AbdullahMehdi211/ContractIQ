from claims.models import ClaimLine
from plugins.claim_validation.plugin import ClaimValidationPlugin
from claims.justification_engine import generate_justification
from claims.gpt_explainer import generate_gpt_explanation


def main():
    claim = ClaimLine(
        claim_id="CLM-001",
        document_name=None,
        medication_type="Specialty",
        drug_name="IVIG Specialty reimbursement",
        quantity=10,
        wac_price=100.0,
        paid_amount=820.0,
    )

    validator = ClaimValidationPlugin()
    result = validator.validate_claim(claim)

    # Deterministic justification (source of truth)
    result["justification"] = generate_justification(
        claim_id=result["claim_id"],
        expected_amount=result["expected_amount"],
        paid_amount=result["paid_amount"],
        variance=result["variance"],
        rate_text=result["matched_rate_text"],
    )

    # GPT explanation layer (presentation)
    result["gpt_explanation"] = generate_gpt_explanation(result)

    print("\nCLAIM VALIDATION RESULT:\n")
    print(result)


if __name__ == "__main__":
    main()
