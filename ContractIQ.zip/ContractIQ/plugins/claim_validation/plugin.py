from typing import Dict

from claims.models import ClaimLine
from claims.rate_parser import parse_rate_from_text
from claims.rate_calculator import calculate_expected_amount
from plugins.rates_search.plugin import RatesSearchPlugin


class ClaimValidationPlugin:
    def __init__(self):
        self.search = RatesSearchPlugin()

    def validate_claim(self, claim: ClaimLine) -> Dict:
        # retrieve best matching rate record
        hits = self.search.hybrid_search(
            query=claim.drug_name,
            medication_type=claim.medication_type,
            document_name=claim.document_name,
            top_k=1,
        )

        if not hits:
            return {
                "claim_id": claim.claim_id,
                "status": "NO_RATE_FOUND",
                "expected_amount": None,
                "paid_amount": claim.paid_amount,
                "variance": None,
                "matched_rate_text": None,
            }

        rate_text = hits[0]["text"]
        rate = parse_rate_from_text(rate_text)

        expected = calculate_expected_amount(
            wac_price=claim.wac_price,
            quantity=claim.quantity,
            rate=rate,
        )
        variance = round(claim.paid_amount - expected, 2)

        status = "OK" if abs(variance) < 0.01 else "MISMATCH"

        return {
            "claim_id": claim.claim_id,
            "status": status,
            "expected_amount": expected,
            "paid_amount": claim.paid_amount,
            "variance": variance,
            "matched_rate_text": rate_text,
        }
