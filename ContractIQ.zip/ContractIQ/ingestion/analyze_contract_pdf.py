import os
import json
from pathlib import Path

from azure.ai.formrecognizer import DocumentAnalysisClient
from azure.core.credentials import AzureKeyCredential
from dotenv import load_dotenv

from ingestion.blob_io import list_contract_blobs, download_blob_bytes

load_dotenv()

OUTPUT_DIR = Path("data/raw_layout")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

client = DocumentAnalysisClient(
    endpoint=os.environ["AZURE_DOCUMENT_INTELLIGENCE_ENDPOINT"],
    credential=AzureKeyCredential(
        os.environ["AZURE_DOCUMENT_INTELLIGENCE_KEY"]
    ),
)

def analyze_pdf(blob_name: str, pdf_bytes: bytes):
    print(f"Analyzing: {blob_name}")

    poller = client.begin_analyze_document(
        model_id="prebuilt-layout",
        document=pdf_bytes,
    )
    result = poller.result()

    output_path = OUTPUT_DIR / f"{blob_name}.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result.to_dict(), f, indent=2)

    print(f"Saved layout JSON → {output_path}")

def main():
    blobs = list_contract_blobs()
    for blob in blobs:
        pdf_bytes = download_blob_bytes(blob)
        analyze_pdf(blob, pdf_bytes)

if __name__ == "__main__":
    main()
