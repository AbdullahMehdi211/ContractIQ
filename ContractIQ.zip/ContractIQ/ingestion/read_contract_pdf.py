import os
from ingestion.blob_io import list_contract_blobs, download_blob_bytes

def main():
    prefix = os.getenv("CONTRACT_PREFIX") or None

    blobs = list_contract_blobs(prefix=prefix)
    if not blobs:
        print("No PDF blobs found in the container.")
        return

    print(f"Found {len(blobs)} PDF(s):")
    for name in blobs:
        print(" -", name)

    # Download the first one as a quick test
    test_blob = blobs[0]
    data = download_blob_bytes(test_blob)

    print("\nDownloaded test PDF successfully!")
    print("Blob:", test_blob)
    print("Size (bytes):", len(data))

if __name__ == "__main__":
    main()
