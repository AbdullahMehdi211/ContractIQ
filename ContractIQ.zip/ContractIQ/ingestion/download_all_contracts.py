# Optionally download all contract PDFs from blob storage to a local directory.

import os
from pathlib import Path
from ingestion.blob_io import list_contract_blobs, download_blob_bytes

def main():
    out_dir = Path("data/contracts")
    out_dir.mkdir(parents=True, exist_ok=True)

    blobs = list_contract_blobs(prefix=os.getenv("CONTRACT_PREFIX") or None)
    print(f"Found {len(blobs)} PDF(s). Downloading...")

    for name in blobs:
        pdf_bytes = download_blob_bytes(name)

        # Save with just filename (strip folders)
        local_name = Path(name).name
        out_path = out_dir / local_name
        out_path.write_bytes(pdf_bytes)

        print(f"Saved: {out_path} ({len(pdf_bytes)} bytes)")

if __name__ == "__main__":
    main()
