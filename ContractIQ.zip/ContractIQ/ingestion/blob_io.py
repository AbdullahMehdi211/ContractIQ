import os
from typing import List, Optional
from dotenv import load_dotenv
from azure.storage.blob import BlobServiceClient

load_dotenv()

def _require(name: str) -> str:
    v = os.getenv(name)
    if not v:
        raise RuntimeError(f"Missing environment variable: {name}")
    return v

def get_blob_service_client() -> BlobServiceClient:
    account_name = _require("AZURE_STORAGE_ACCOUNT_NAME")
    account_key = _require("AZURE_STORAGE_ACCOUNT_KEY")

    account_url = f"https://{account_name}.blob.core.windows.net"
    return BlobServiceClient(account_url=account_url, credential=account_key)

def get_container_name() -> str:
    return os.getenv("AZURE_STORAGE_CONTAINER", "contracts")

def list_contract_blobs(prefix: Optional[str] = None) -> List[str]:
    client = get_blob_service_client()
    container = client.get_container_client(get_container_name())

    names = []
    for b in container.list_blobs(name_starts_with=prefix):
        # only PDFs (optional filter)
        if b.name.lower().endswith(".pdf"):
            names.append(b.name)
    return names

def download_blob_bytes(blob_name: str) -> bytes:
    client = get_blob_service_client()
    blob_client = client.get_blob_client(container=get_container_name(), blob=blob_name)
    return blob_client.download_blob().readall()
