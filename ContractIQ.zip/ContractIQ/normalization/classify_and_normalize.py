import json
from pathlib import Path
from typing import List, Dict, Any


def parse_percent(val: str) -> float:
    if not val:
        return 0.0

    val = val.replace("%", "").replace(" ", "").replace("-", "")

    # 🚫 guard against headers like "WAC"
    try:
        return float(val) / 100.0
    except ValueError:
        return 0.0


def parse_dollar(val: str) -> float:
    if not val:
        return 0.0

    val = val.replace("$", "").replace(" ", "").replace("-", "")

    # 🚫 guard against headers like "Disp Fee"
    try:
        return float(val)
    except ValueError:
        return 0.0


def is_non_specialty_table(table: List[Dict[str, str]]) -> bool:
    # Non-specialty tables usually have a single "Rate" row
    return any(
        row.get("0", "").strip().lower() == "rate"
        for row in table
    )


def is_specialty_table(table: List[Dict[str, str]]) -> bool:
    # Specialty tables list product categories
    for row in table:
        label = row.get("0", "").lower()
        if "products" in label or "specialty" in label:
            return True
    return False


def normalize_non_specialty(
    table: List[Dict[str, str]],
    document_name: str
) -> Dict[str, Any]:

    rate_row = None

    for row in table:
        if row.get("0", "").strip().lower() == "rate":
            rate_row = row
            break

    if rate_row is None:
        raise ValueError("Non-specialty table found but no Rate row")

    return {
        "document_name": document_name,
        "medication_type": "Non-Specialty",
        "category": "Base Rate",
        "brand_wac_discount": parse_percent(rate_row.get("1")),
        "brand_dispensing_fee": parse_dollar(rate_row.get("2")),
        "generic_wac_discount": parse_percent(rate_row.get("3")),
        "generic_dispensing_fee": parse_dollar(rate_row.get("4")),
        "mac_dispensing_fee": parse_dollar(rate_row.get("5")),
    }


def normalize_specialty(
    table: List[Dict[str, str]],
    document_name: str
) -> List[Dict[str, Any]]:

    normalized = []

    for row in table:
        category = row.get("0", "").strip()
        if not category or category.lower() in ("rate", ""):
            continue

        normalized.append({
            "document_name": document_name,
            "medication_type": "Specialty",
            "category": category,
            "brand_wac_discount": parse_percent(row.get("1")),
            "brand_dispensing_fee": parse_dollar(row.get("2")),
            "generic_wac_discount": parse_percent(row.get("3")),
            "generic_dispensing_fee": parse_dollar(row.get("4")),
            "mac_dispensing_fee": parse_dollar(row.get("5")),
        })

    return normalized


def process_extracted_file(path: Path) -> List[Dict[str, Any]]:
    data = json.loads(path.read_text(encoding="utf-8"))
    document = data["document"]
    results = []

    for table in data["tables"]:
        if is_non_specialty_table(table):
            results.append(
                normalize_non_specialty(table, f"{document}.pdf")
            )

        if is_specialty_table(table):
            results.extend(
                normalize_specialty(table, f"{document}.pdf")
            )

    return results


def main():
    input_dir = Path("data/extracted_tables")
    output_dir = Path("data/normalized_rates")
    output_dir.mkdir(parents=True, exist_ok=True)

    all_rates = []

    for file in input_dir.glob("*_tables.json"):
        all_rates.extend(process_extracted_file(file))

    out_path = output_dir / "rates_normalized.json"
    out_path.write_text(
        json.dumps(all_rates, indent=2),
        encoding="utf-8"
    )

    print(f"Normalized {len(all_rates)} rate records → {out_path}")


if __name__ == "__main__":
    main()
