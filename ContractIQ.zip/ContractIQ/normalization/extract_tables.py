import json
from pathlib import Path
from typing import List, Dict, Any

RAW_LAYOUT_DIR = Path("data/raw_layout")
OUTPUT_DIR = Path("data/extracted_tables")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def extract_tables_from_layout(layout_json: Dict[str, Any]) -> List[List[Dict[int, str]]]:
    """
    Returns a list of tables.
    Each table is a list of row dicts: {column_index: cell_text}
    """
    tables = []

    for table in layout_json.get("tables", []):
        rows: Dict[int, Dict[int, str]] = {}

        for cell in table["cells"]:
            row_idx = cell["row_index"]
            col_idx = cell["column_index"]
            content = cell.get("content", "").strip()

            rows.setdefault(row_idx, {})[col_idx] = content

        ordered_rows = [rows[i] for i in sorted(rows)]
        tables.append(ordered_rows)

    return tables


def process_layout_file(path: Path):
    with open(path, "r", encoding="utf-8") as f:
        layout = json.load(f)

    tables = extract_tables_from_layout(layout)

    out_path = OUTPUT_DIR / path.name.replace(".json", "_tables.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(
            {
                "document": path.name.replace(".pdf.json", ""),
                "table_count": len(tables),
                "tables": tables,
            },
            f,
            indent=2,
        )

    print(f"Extracted {len(tables)} tables → {out_path}")


def main():
    for file in RAW_LAYOUT_DIR.glob("*.json"):
        process_layout_file(file)


if __name__ == "__main__":
    main()
