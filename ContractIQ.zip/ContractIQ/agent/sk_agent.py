# Build the Kernel + Agent

import os
from dotenv import load_dotenv

from semantic_kernel.kernel import Kernel
from semantic_kernel.connectors.ai.open_ai import AzureChatCompletion
from semantic_kernel.agents import ChatCompletionAgent
from semantic_kernel.connectors.ai.function_choice_behavior import FunctionChoiceBehavior

from agent.tools import ClaimTools

load_dotenv()


def create_kernel() -> Kernel:
    kernel = Kernel()

    # Add Azure OpenAI chat service to Kernel :contentReference[oaicite:3]{index=3}
    chat_service = AzureChatCompletion(
        service_id="aoai-chat",
        deployment_name=os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT"],
        endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
        api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
    )
    kernel.add_service(chat_service)

    # Register plugin (tools) :contentReference[oaicite:4]{index=4}
    kernel.add_plugin(ClaimTools(), plugin_name="claims")

    return kernel


def create_agent(kernel: Kernel) -> ChatCompletionAgent:
    instructions = """
You are a pharmacy claims validation agent.

You MUST use tools when you need to validate a claim.
- Use claims.validate_claim to calculate expected reimbursement and compare to paid amount.
- Never invent discounts, fees, or contract rules.
- Prefer returning final answers as short bullet points.

When a user provides claim details, call the tool and then explain the result clearly.
"""

    agent = ChatCompletionAgent(
        name="ClaimValidationAgent",
        instructions=instructions,
        kernel=kernel,
        # Enable auto tool calling (agent decides when to call your functions) :contentReference[oaicite:5]{index=5}
        function_choice_behavior=FunctionChoiceBehavior.Auto(),
    )
    return agent
