import asyncio

from agent.sk_agent import create_kernel, create_agent


async def main():
    kernel = create_kernel()
    agent = create_agent(kernel)

    # User asks in natural language:
    user_message = """
Validate this claim:
claim_id=CLM-001
medication_type=Specialty
drug_name=IVIG Specialty reimbursement
quantity=10
wac_price=100
paid_amount=820
"""

    # Agent invocation is async; iterate streaming responses :contentReference[oaicite:7]{index=7}
    async for response in agent.invoke(messages=user_message):
        print(response.content)


if __name__ == "__main__":
    asyncio.run(main())
