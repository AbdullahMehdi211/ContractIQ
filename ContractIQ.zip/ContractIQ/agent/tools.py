# Create SK “tools” (plugins) that wrap your existing code

import json
from typing import Optional, Dict, Any

from semantic_kernel.functions import kernel_function

from claims.models import ClaimLine
from plugins.claim_validation.plugin import ClaimValidationPlugin
from claims.justification_engine import generate_justification
from claims.gpt_explainer import generate_gpt_explanation


class ClaimTools:
    """
    Semantic Kernel Plugin: deterministic claim validation + justification + GPT explanation.
    We return JSON strings so the model can safely read results.
    """

    def __init__(self):
        self.validator = ClaimValidationPlugin()

    @kernel_function(
        description="Validate a pharmacy claim against contract rates (deterministic). Returns JSON."
    )
    def validate_claim(
        self,
        claim_id: str,
        medication_type: str,
        drug_name: str,
        quantity: float,
        wac_price: float,
        paid_amount: float,
        document_name: Optional[str] = None,
    ) -> str:
        claim = ClaimLine(
            claim_id=claim_id,
            document_name=document_name,
            medication_type=medication_type,
            drug_name=drug_name,
            quantity=quantity,
            wac_price=wac_price,
            paid_amount=paid_amount,
        )

        result: Dict[str, Any] = self.validator.validate_claim(claim)

        # If a rate wasn’t found, return quickly
        if result.get("status") == "NO_RATE_FOUND":
            return json.dumps(result, indent=2)

        # Deterministic justification (source-of-truth)
        result["justification"] = generate_justification(
            claim_id=result["claim_id"],
            expected_amount=result["expected_amount"],
            paid_amount=result["paid_amount"],
            variance=result["variance"],
            rate_text=result["matched_rate_text"],
        )

        # GPT explanation (presentation layer)
        result["gpt_explanation"] = generate_gpt_explanation(result)

        return json.dumps(result, indent=2)
