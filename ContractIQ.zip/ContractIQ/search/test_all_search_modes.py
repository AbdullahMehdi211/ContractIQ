import os
from dotenv import load_dotenv
from typing import List

from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from azure.search.documents.models import VectorizedQuery
from openai import AzureOpenAI

load_dotenv()

INDEX_NAME = "contract-rates"
VECTOR_DIM = 1536


def print_results(title: str, results):
    print("\n" + "=" * 60)
    print(title)
    print("=" * 60)
    for i, r in enumerate(results, start=1):
        print(
            f"{i}. {r['category']} | "
            f"{r['medication_type']} | "
            f"{r['document_name']}"
        )


def main():
    # --- Clients ---
    search_client = SearchClient(
        endpoint=os.environ["AZURE_SEARCH_ENDPOINT"],
        index_name=INDEX_NAME,
        credential=AzureKeyCredential(os.environ["AZURE_SEARCH_ADMIN_KEY"]),
    )

    aoai = AzureOpenAI(
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        api_version="2024-02-15-preview",
    )

    embedding_model = os.environ["AZURE_OPENAI_EMBEDDING_DEPLOYMENT"]

    query = "IVIG Specialty reimbursement"
    print(f"\n🔍 TEST QUERY: '{query}'")

    # ==========================================================
    # 1️⃣ KEYWORD SEARCH (BM25)
    # ==========================================================
    keyword_results = search_client.search(
        search_text=query,
        top=5
    )

    keyword_hits = list(keyword_results)
    print_results("1️⃣ KEYWORD SEARCH (BM25)", keyword_hits)

    # ==========================================================
    # 2️⃣ VECTOR SEARCH ONLY
    # ==========================================================
    embedding = aoai.embeddings.create(
        model=embedding_model,
        input=query,
    ).data[0].embedding

    vector_query = VectorizedQuery(
        vector=embedding,
        fields="text_vector",
        k_nearest_neighbors=5,
    )

    vector_results = search_client.search(
        search_text=None,
        vector_queries=[vector_query],
        top=5,
    )

    vector_hits = list(vector_results)
    print_results("2️⃣ VECTOR SEARCH (EMBEDDINGS)", vector_hits)

    # ==========================================================
    # 3️⃣ HYBRID SEARCH (BM25 + VECTOR)
    # ==========================================================
    hybrid_results = search_client.search(
        search_text=query,
        vector_queries=[vector_query],
        filter="medication_type eq 'Specialty'",
        top=5,
    )

    hybrid_hits = list(hybrid_results)
    print_results("3️⃣ HYBRID SEARCH (BM25 + VECTOR)", hybrid_hits)

    print("\n✅ ALL SEARCH MODES TESTED SUCCESSFULLY")


if __name__ == "__main__":
    main()
