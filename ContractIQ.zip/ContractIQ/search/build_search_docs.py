import json
import uuid
from pathlib import Path
from typing import List, Dict, Any

NORMALIZED_PATH = Path("data/normalized_rates/rates_normalized.json")
OUTPUT_DIR = Path("data/search_docs")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

OUTPUT_PATH = OUTPUT_DIR / "rate_search_docs.json"


def to_search_text(r: Dict[str, Any]) -> str:
    return (
        f"Document: {r['document_name']} | "
        f"Medication type: {r['medication_type']} | "
        f"Category: {r['category']} | "
        f"Brand WAC discount: {r['brand_wac_discount']:.2%} | "
        f"Brand dispensing fee: ${r['brand_dispensing_fee']:.2f} | "
        f"Generic WAC discount: {r['generic_wac_discount']:.2%} | "
        f"Generic dispensing fee: ${r['generic_dispensing_fee']:.2f} | "
        f"MAC dispensing fee: ${r['mac_dispensing_fee']:.2f}"
    )


def main():
    if not NORMALIZED_PATH.exists():
        raise FileNotFoundError(f"Missing: {NORMALIZED_PATH}. Run normalization first.")

    rates: List[Dict[str, Any]] = json.loads(
        NORMALIZED_PATH.read_text(encoding="utf-8")
    )

    docs = []
    for r in rates:
        docs.append({
            "id": str(uuid.uuid4()),
            "document_name": r["document_name"],
            "medication_type": r["medication_type"],
            "category": r["category"],
            "text": to_search_text(r),
        })

    OUTPUT_PATH.write_text(json.dumps(docs, indent=2), encoding="utf-8")

    print(f"Created {len(docs)} search docs → {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
