import os
from dotenv import load_dotenv

from azure.core.credentials import AzureKeyCredential
from azure.search.documents.indexes import SearchIndexClient
from azure.search.documents.indexes.models import (
    SearchIndex,
    SimpleField,
    SearchableField,
    SearchField,              # 👈 IMPORTANT
    VectorSearch,
    HnswAlgorithmConfiguration,
    VectorSearchProfile,
)

load_dotenv()

INDEX_NAME = "contract-rates"

def main():
    endpoint = os.environ["AZURE_SEARCH_ENDPOINT"]
    key = os.environ["AZURE_SEARCH_ADMIN_KEY"]

    client = SearchIndexClient(
        endpoint=endpoint,
        credential=AzureKeyCredential(key),
    )

    # 🔥 Delete index
    try:
        client.delete_index(INDEX_NAME)
        print(f"🗑️ Deleted existing index: {INDEX_NAME}")
    except Exception:
        print("ℹ️ Index did not exist")

    fields = [
        SimpleField(name="id", type="Edm.String", key=True),

        SimpleField(name="document_name", type="Edm.String", filterable=True),
        SimpleField(name="medication_type", type="Edm.String", filterable=True),
        SimpleField(name="category", type="Edm.String", filterable=True),

        SimpleField(name="brand_wac_discount", type="Edm.Double"),
        SimpleField(name="brand_dispensing_fee", type="Edm.Double"),
        SimpleField(name="generic_wac_discount", type="Edm.Double"),
        SimpleField(name="generic_dispensing_fee", type="Edm.Double"),
        SimpleField(name="mac_dispensing_fee", type="Edm.Double"),

        SearchableField(name="text", type="Edm.String"),

        # ✅ VECTOR FIELD (CORRECT)
        SearchField(
            name="text_vector",
            type="Collection(Edm.Single)",
            searchable=True,
            vector_search_dimensions=1536,
            vector_search_profile_name="default-vector-profile",
        ),
    ]

    vector_search = VectorSearch(
        algorithms=[
            HnswAlgorithmConfiguration(name="default-hnsw")
        ],
        profiles=[
            VectorSearchProfile(
                name="default-vector-profile",
                algorithm_configuration_name="default-hnsw",
            )
        ],
    )

    index = SearchIndex(
        name=INDEX_NAME,
        fields=fields,
        vector_search=vector_search,
    )

    client.create_index(index)
    print(f"✅ Vector index created successfully: {INDEX_NAME}")

if __name__ == "__main__":
    main()
