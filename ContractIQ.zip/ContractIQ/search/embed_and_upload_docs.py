import os
import json
from pathlib import Path
from typing import List, Dict, Any

from azure.core.credentials import AzureKeyCredential
from azure.search.documents import SearchClient
from openai import AzureOpenAI
from dotenv import load_dotenv

load_dotenv()

# ---------- Paths ----------
INPUT_PATH = Path("data/search_docs/rate_search_docs.json")

# ---------- Azure clients ----------
search_client = SearchClient(
    endpoint=os.environ["AZURE_SEARCH_ENDPOINT"],
    index_name=os.environ["AZURE_SEARCH_INDEX_NAME"],
    credential=AzureKeyCredential(os.environ["AZURE_SEARCH_ADMIN_KEY"]),
)

aoai = AzureOpenAI(
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    api_version="2024-02-15-preview",
)

EMBEDDING_DEPLOYMENT = os.environ["AZURE_OPENAI_EMBEDDING_DEPLOYMENT"]
VECTOR_DIMENSION = 1536  # text-embedding-3-small


def embed_text(text: str) -> List[float]:
    """Generate embedding for a single text string."""
    response = aoai.embeddings.create(
        model=EMBEDDING_DEPLOYMENT,
        input=[text],  # MUST be a list
    )
    return response.data[0].embedding


def main():
    if not INPUT_PATH.exists():
        raise FileNotFoundError(f"Missing {INPUT_PATH}. Run Step 7A first.")

    docs: List[Dict[str, Any]] = json.loads(INPUT_PATH.read_text(encoding="utf-8"))

    upload_batch = []

    print(f"Embedding and uploading {len(docs)} documents...")

    for i, doc in enumerate(docs, start=1):
        text = doc["text"]

        print(f"[{i}/{len(docs)}] Embedding doc: {doc['category']}")

        vector = embed_text(text)

        if len(vector) != VECTOR_DIMENSION:
            raise ValueError(
                f"Embedding dimension mismatch: {len(vector)} != {VECTOR_DIMENSION}"
            )

        doc["text_vector"] = vector
        upload_batch.append(doc)

    result = search_client.upload_documents(upload_batch)

    succeeded = sum(1 for r in result if r.succeeded)
    failed = len(result) - succeeded

    print("----------")
    print(f"Upload complete")
    print(f"✅ Succeeded: {succeeded}")
    print(f"❌ Failed: {failed}")


if __name__ == "__main__":
    main()
