import re
from typing import Dict


def _pct_to_float(p: str) -> float:
    # "-18.00%" -> -0.18
    p = p.replace("%", "").strip()
    return float(p) / 100.0


def _dollar_to_float(d: str) -> float:
    # "$0.30" -> 0.30
    d = d.replace("$", "").strip()
    return float(d)


def parse_rate_from_text(text: str) -> Dict:
    """
    Extracts rate values from the 'text' field produced by build_search_docs.py
    """
    # Use regex to pull out the exact segments
    brand_disc = re.search(r"Brand WAC discount:\s*([-\d.]+%)", text)
    brand_fee = re.search(r"Brand dispensing fee:\s*\$([-\d.]+)", text)

    generic_disc = re.search(r"Generic WAC discount:\s*([-\d.]+%)", text)
    generic_fee = re.search(r"Generic dispensing fee:\s*\$([-\d.]+)", text)

    mac_fee = re.search(r"MAC dispensing fee:\s*\$([-\d.]+)", text)

    return {
        "brand_wac_discount": _pct_to_float(brand_disc.group(1)) if brand_disc else 0.0,
        "brand_dispensing_fee": _dollar_to_float(brand_fee.group(1)) if brand_fee else 0.0,
        "generic_wac_discount": _pct_to_float(generic_disc.group(1)) if generic_disc else 0.0,
        "generic_dispensing_fee": _dollar_to_float(generic_fee.group(1)) if generic_fee else 0.0,
        "mac_dispensing_fee": _dollar_to_float(mac_fee.group(1)) if mac_fee else 0.0,
    }
