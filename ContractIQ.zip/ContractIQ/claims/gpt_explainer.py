import json
import os
from typing import Dict, Any

from dotenv import load_dotenv
from openai import AzureOpenAI

load_dotenv()


def generate_gpt_explanation(result: Dict[str, Any]) -> str:
    """
    GPT explanation layer:
    - Reads deterministic result JSON
    - Produces a human-friendly explanation
    - Must not introduce new facts or change numbers
    """

    chat_deployment = os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT"]

    client = AzureOpenAI(
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        api_version=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-15-preview"),
    )

    # Only pass the facts GPT is allowed to use
    facts = {
        "claim_id": result.get("claim_id"),
        "status": result.get("status"),
        "expected_amount": result.get("expected_amount"),
        "paid_amount": result.get("paid_amount"),
        "variance": result.get("variance"),
        "justification": result.get("justification"),  # deterministic
        "matched_rate_text": result.get("matched_rate_text"),
    }

    system_msg = (
        "You are a compliance-safe claim explanation assistant.\n"
        "Rules:\n"
        "1) Use ONLY the JSON facts provided by the user.\n"
        "2) Do NOT invent numbers, discounts, fees, documents, or rules.\n"
        "3) If something is missing, say it is not available.\n"
        "4) Keep it short, clear, and professional.\n"
        "Output: a short paragraph explanation."
    )

    user_msg = (
        "Explain the claim decision in plain English using ONLY these facts:\n\n"
        f"{json.dumps(facts, indent=2)}"
    )

    # Chat Completions expects messages; model is your deployment name. :contentReference[oaicite:1]{index=1}
    resp = client.chat.completions.create(
        model=chat_deployment,
        messages=[
            {"role": "system", "content": system_msg},
            {"role": "user", "content": user_msg},
        ],
        temperature=0.2,
        max_tokens=220,
    )

    return resp.choices[0].message.content.strip()
