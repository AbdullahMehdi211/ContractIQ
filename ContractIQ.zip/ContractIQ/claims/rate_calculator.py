from typing import Dict


def calculate_expected_amount(wac_price: float, quantity: float, rate: Dict) -> float:
    """
    Example deterministic reimbursement:
    expected = (WAC * (1 + discount)) * quantity + dispensing_fee
    NOTE: discounts are negative like -0.18 for -18%
    """
    brand_discount = rate.get("brand_wac_discount", 0.0)
    dispensing_fee = rate.get("brand_dispensing_fee", 0.0)

    base = wac_price * (1.0 + brand_discount)
    expected = (base * quantity) + dispensing_fee
    return round(expected, 2)
