from pydantic import BaseModel, Field
from typing import Optional


class ClaimLine(BaseModel):
    claim_id: str = Field(..., description="Unique claim identifier")
    document_name: Optional[str] = Field(None, description="Contract document name (optional filter)")
    medication_type: Optional[str] = Field(None, description="Non-Specialty or Specialty (optional filter)")

    drug_name: str = Field(..., description="Drug name or category text the user searches for")
    quantity: float = Field(..., description="Quantity dispensed")
    wac_price: float = Field(..., description="WAC price per unit")
    paid_amount: float = Field(..., description="Amount actually paid")
