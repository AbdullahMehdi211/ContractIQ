from typing import Dict


def generate_justification(
    claim_id: str,
    expected_amount: float,
    paid_amount: float,
    variance: float,
    rate_text: str,
) -> Dict:
    if abs(variance) < 0.01:
        status = "OK"
        reason = "Payment matches expected reimbursement"
    elif variance < 0:
        status = "MISMATCH"
        reason = "Underpayment detected"
    else:
        status = "MISMATCH"
        reason = "Overpayment detected"

    return {
        "claim_id": claim_id,
        "status": status,
        "reason": reason,
        "expected_amount": expected_amount,
        "paid_amount": paid_amount,
        "difference": abs(variance),
        "rule_applied": rate_text,
    }
